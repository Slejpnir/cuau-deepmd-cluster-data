Cu-Au DeepMD six-configuration prospective test, 8 November 2026

This companion archive supplements, but does not modify, the published v2026-11-06 data.
The principal model was fitted to 259 configurations and fixed before the new QE labels were available.
Four metal-only Ar13 trajectory snapshots and two unrelaxed Cu28Au27 seeds are included.
All references are excluded from fitting and model selection. No energy offset was fitted.
The reference cell is 24 Angstrom; full cell-size convergence has not been established.
The first 24/26 Angstrom energy difference was 1.098 meV/atom, exceeding the 1 meV/atom target.
PBE, 80/320 Ry, Gamma-only, MV smearing 0.02 Ry, MT correction, conv_thr 1e-7 Ry, Davidson, 328 bands.
Prediction positions and atom order are preserved. Inference was nonperiodic.
Energies are eV, forces eV/Angstrom, coordinates Angstrom.
Energy RMSE gives equal weight to per-frame energy errors divided by atom count.
Force RMSE pools Cartesian component errors. See summary.json for group metrics.
Run python recompute_metrics.py from this archive directory to reproduce aggregate scores.
Raw QE execution files remain archived separately by the authors; parsed references are included here.
If these results guide later model changes, this cohort becomes exposed validation for those models.
