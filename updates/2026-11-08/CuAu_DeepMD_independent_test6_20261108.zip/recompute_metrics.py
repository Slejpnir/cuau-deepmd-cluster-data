from pathlib import Path
import json,math
root=Path(__file__).resolve().parent
s=json.loads((root/'summary.json').read_text())
rows=[json.loads((root/'frames'/(cid+'.json')).read_text()) for cid in s['candidate_ids']]
for name,group in [('all_six',rows),('four_collision_snapshots',rows[:4]),('two_unrelaxed_geometries',rows[4:])]:
    e=[(r['predicted_energy_eV']-r['reference_energy_eV'])/r['natoms'] for r in group]
    f=[p-q for r in group for a,b in zip(r['predicted_forces_eV_A'],r['reference_forces_eV_A']) for p,q in zip(a,b)]
    values={'energy_RMSE_eV_per_atom':math.sqrt(math.fsum(x*x for x in e)/len(e)),
        'energy_MAE_eV_per_atom':math.fsum(abs(x) for x in e)/len(e),
        'force_RMSE_eV_A':math.sqrt(math.fsum(x*x for x in f)/len(f)),
        'force_MAE_eV_A':math.fsum(abs(x) for x in f)/len(f),
        'force_maximum_absolute_component_error_eV_A':max(abs(x) for x in f)}
    assert all(math.isclose(v,s['metrics'][name][k],rel_tol=1e-10,abs_tol=1e-10) for k,v in values.items())
    print(name,json.dumps(values,sort_keys=True))
